---
name: 🐛 Bug Report
about: Report a bug to help us improve YT Downloader
title: "[BUG] "
labels: bug
assignees: ''
---

## 🐛 Bug Description

A clear and concise description of what the bug is.

---

## 🔁 Steps to Reproduce

1. Open the app
2. Paste URL: `...`
3. Select quality: `...`
4. Click Download
5. See error: `...`

---

## ✅ Expected Behaviour

What did you expect to happen?

---

## ❌ Actual Behaviour

What actually happened?

---

## 📸 Screenshots

If applicable, add screenshots or terminal output here.

---

## 💻 Environment

| Detail | Value |
|--------|-------|
| OS | e.g. Windows 11, Ubuntu 22.04 |
| Python version | e.g. 3.11.5 |
| yt-dlp version | run `yt-dlp --version` |
| FFmpeg installed | Yes / No |
| App version | e.g. 1.0.0 |

---

## 📋 Terminal Output

```
Paste the full terminal output here (if available)
```

---

## 📎 Additional Context

Add any other context about the problem here.
