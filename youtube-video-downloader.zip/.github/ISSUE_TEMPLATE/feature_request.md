---
name: 💡 Feature Request
about: Suggest a new feature or improvement for YT Downloader
title: "[FEATURE] "
labels: enhancement
assignees: ''
---

## 💡 Feature Summary

A brief, clear description of the feature you'd like.

---

## 🔍 Problem This Solves

Describe the problem or limitation you're experiencing. What can't you do right now that you wish you could?

---

## 🛠 Proposed Solution

Describe the solution you'd like to see. How should it work from the user's perspective?

---

## 🔄 Alternatives Considered

Have you tried any workarounds or alternative approaches? Why weren't they satisfactory?

---

## 📸 Mockups / Examples

If you have a visual idea or reference (screenshots, diagrams, links), add them here.

---

## 🎯 Priority

How important is this to you?

- [ ] 🔴 Critical — I can't use the app without this
- [ ] 🟠 High — This would significantly improve my workflow
- [ ] 🟡 Medium — Nice to have
- [ ] 🟢 Low — Just an idea

---

## 📎 Additional Context

Any other context, links, or references that might help.
