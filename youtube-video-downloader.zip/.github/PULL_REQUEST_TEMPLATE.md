## 📝 Summary

Provide a concise description of **what** this PR changes and **why**.

Closes #<!-- issue number -->

---

## 🔄 Type of Change

- [ ] 🐛 Bug fix (non-breaking change that fixes an issue)
- [ ] ✨ New feature (non-breaking change that adds functionality)
- [ ] 💥 Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] 📖 Documentation update
- [ ] 🔧 Refactor / code cleanup
- [ ] 🔒 Security fix

---

## 🧪 How Has This Been Tested?

Describe the testing you performed. Include:
- Python version(s) tested
- Operating system(s)
- Steps taken to verify the change works

---

## ✅ Checklist

- [ ] My code follows the project's coding standards (PEP 8)
- [ ] I have added docstrings to new functions/classes
- [ ] Thread-safe: any new shared state uses `state_lock`
- [ ] I have tested on Windows, Linux, or macOS
- [ ] I have updated `docs/CHANGELOG.md` under `[Unreleased]`
- [ ] I have read [CONTRIBUTING.md](../CONTRIBUTING.md)

---

## 📸 Screenshots (if applicable)

Before | After
--- | ---
*screenshot* | *screenshot*

---

## 📎 Additional Notes

Any extra context for reviewers.
