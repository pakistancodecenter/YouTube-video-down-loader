import sys
import threading
import os
import time
import shutil
import logging
import uuid

import yt_dlp
from flask import Flask, request, jsonify
from PySide6.QtWidgets import QApplication, QMainWindow
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtCore import QUrl

# -------------------------------
# Logging
# -------------------------------
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("youtube-video-downloader")

# -------------------------------
# Flask App
# -------------------------------
app = Flask(__name__)

DOWNLOAD_FOLDER = os.path.join(os.path.expanduser("~"), "Downloads")
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

HAS_FFMPEG = shutil.which("ffmpeg") is not None
if not HAS_FFMPEG:
    logger.warning("ffmpeg not found on PATH. HD (video+audio) merging will be unavailable; "
                   "falling back to pre-muxed formats.")

# Shared state
progress_data = {}
stop_flags = {}
state_lock = threading.Lock()

# How long to keep a finished/errored task before purging (seconds)
TASK_TTL = 600


def safe_update_progress(task_id, **kwargs):
    """Thread-safe update for progress_data[task_id]."""
    with state_lock:
        entry = progress_data.setdefault(task_id, {})
        entry.update(kwargs)
        entry["_ts"] = time.time()


def purge_old_tasks():
    """Remove stale finished/errored/stopped tasks to avoid unbounded growth."""
    now = time.time()
    terminal = {"finished", "stopped"}
    with state_lock:
        for tid in list(progress_data.keys()):
            entry = progress_data[tid]
            done = entry.get("status") in terminal or "error" in entry
            if done and now - entry.get("_ts", now) > TASK_TTL:
                progress_data.pop(tid, None)
                stop_flags.pop(tid, None)


# -------------------------------
# Frontend (HTML + CSS + JS)
# -------------------------------
HTML_PAGE = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>YouTube Downloader</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #f5f7fb;
    --surface: #ffffff;
    --surface2: #f1f5f9;
    --border: #d9d9d9;
    --accent: #ff0000;
    --accent2: #ff5c5c;
    --text: #222222;
    --muted: #666666;
    --success: #16a34a;
    --radius: 14px;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    background: var(--bg);
    color: var(--text);
    font-family: 'DM Sans', sans-serif;
    min-height: 100vh;
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    padding: 20px; position: relative; overflow-x: hidden;
  }
  body::before {
    content: ''; position: fixed; top: -200px; left: 50%;
    transform: translateX(-50%); width: 700px; height: 500px;
    background: radial-gradient(ellipse, rgba(255,77,77,0.12) 0%, transparent 70%);
    pointer-events: none; z-index: 0;
  }
  .wrapper { position: relative; z-index: 1; width: 100%; max-width: 560px; }
  .header { text-align: center; margin-bottom: 28px; animation: slideDown 0.6s ease both; }
  .header .logo { display: inline-flex; align-items: center; gap: 10px; margin-bottom: 8px; }
  .logo-icon {
    width: 42px; height: 42px;
    background: linear-gradient(135deg, var(--accent), var(--accent2));
    border-radius: 12px; display: flex; align-items: center; justify-content: center;
    font-size: 20px; color: #fff; box-shadow: 0 0 20px rgba(255,77,77,0.4);
  }
  .header h1 {
    font-family: 'Syne', sans-serif; font-size: 1.9em; font-weight: 800;
    background: linear-gradient(90deg, var(--text) 30%, var(--accent));
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
    background-clip: text; letter-spacing: -0.5px;
  }
  .header p { color: var(--muted); font-size: 0.88em; margin-top: 4px; }
  .card {
    background: var(--surface); border: 1px solid var(--border);
    border-radius: 20px; padding: 28px;
    animation: slideUp 0.6s 0.15s ease both; opacity: 0;
  }
  .url-wrap { position: relative; margin-bottom: 16px; }
  .url-icon {
    position: absolute; left: 14px; top: 50%; transform: translateY(-50%);
    font-size: 16px; color: var(--muted); pointer-events: none;
  }
  .url-input {
    width: 100%; background: var(--surface2); border: 1px solid var(--border);
    border-radius: var(--radius); padding: 14px 14px 14px 42px; color: var(--text);
    font-family: 'DM Sans', sans-serif; font-size: 0.92em; outline: none;
    transition: border-color 0.2s, box-shadow 0.2s;
  }
  .url-input::placeholder { color: #888; }
  .url-input:focus {
    border-color: rgba(255,77,77,0.5); box-shadow: 0 0 0 3px rgba(255,77,77,0.08);
  }
  .quality-row { display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; margin-bottom: 20px; }
  .quality-btn {
    background: var(--surface2); border: 1px solid var(--border); border-radius: 10px;
    padding: 10px 6px; color: var(--muted); font-family: 'Syne', sans-serif;
    font-size: 0.72em; font-weight: 600; cursor: pointer; transition: all 0.2s; text-align: center;
  }
  .quality-btn:hover { border-color: rgba(255,77,77,0.4); color: var(--text); }
  .quality-btn.active {
    background: linear-gradient(135deg, rgba(255,77,77,0.2), rgba(255,140,66,0.15));
    border-color: var(--accent); color: var(--text); box-shadow: 0 0 12px rgba(255,77,77,0.15);
  }
  .quality-btn .q-icon { font-size: 1.2em; display: block; margin-bottom: 3px; }
  .btn-row { display: grid; grid-template-columns: 1fr auto; gap: 10px; margin-bottom: 20px; }
  .btn-download {
    background: linear-gradient(135deg, var(--accent), var(--accent2)); border: none;
    border-radius: var(--radius); padding: 14px 20px; color: white;
    font-family: 'Syne', sans-serif; font-size: 0.95em; font-weight: 700; cursor: pointer;
    transition: all 0.25s; display: flex; align-items: center; justify-content: center;
    gap: 8px; box-shadow: 0 4px 20px rgba(255,77,77,0.25); letter-spacing: 0.3px;
  }
  .btn-download:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 6px 28px rgba(255,77,77,0.4); }
  .btn-download:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }
  .btn-stop {
    background: var(--surface2); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 14px 16px; color: var(--muted); font-family: 'DM Sans', sans-serif;
    font-size: 0.9em; cursor: pointer; transition: all 0.2s; white-space: nowrap;
  }
  .btn-stop:hover { border-color: rgba(255,77,77,0.4); color: var(--accent); }
  .progress-wrap {
    background: var(--surface2); border-radius: 99px; height: 6px; overflow: hidden;
    margin-bottom: 12px; opacity: 0; transition: opacity 0.3s;
  }
  .progress-wrap.visible { opacity: 1; }
  .progress-fill {
    height: 100%; width: 0%;
    background: linear-gradient(90deg, var(--accent), var(--accent2));
    border-radius: 99px; transition: width 0.4s ease; position: relative;
  }
  .progress-fill::after {
    content: ''; position: absolute; right: 0; top: 0; bottom: 0; width: 30px;
    background: linear-gradient(to right, transparent, rgba(255,255,255,0.3)); border-radius: 99px;
  }
  .status {
    display: flex; align-items: center; justify-content: space-between;
    font-size: 0.82em; color: var(--muted); min-height: 20px; transition: all 0.3s;
  }
  .status .status-text { display: flex; align-items: center; gap: 6px; }
  .status .percent { font-family: 'Syne', sans-serif; font-weight: 700; color: var(--text); }
  .status.success .status-text { color: var(--success); }
  .status.error .status-text { color: var(--accent); }
  .spinner {
    width: 12px; height: 12px; border: 2px solid rgba(255,77,77,0.3);
    border-top-color: var(--accent); border-radius: 50%;
    animation: spin 0.7s linear infinite; display: none;
  }
  .spinner.active { display: block; }
  .footer {
    text-align: center; margin-top: 20px; color: #888; font-size: 0.75em;
    animation: slideUp 0.6s 0.3s ease both; opacity: 0;
  }
  @keyframes slideDown { from { opacity: 0; transform: translateY(-20px);} to { opacity: 1; transform: translateY(0);} }
  @keyframes slideUp   { from { opacity: 0; transform: translateY(20px);}  to { opacity: 1; transform: translateY(0);} }
  @keyframes spin      { to { transform: rotate(360deg); } }
</style>
</head>
<body>
<div class="wrapper">
  <div class="header">
    <div class="logo">
      <div class="logo-icon">&#9654;</div>
      <h1>YT Downloader</h1>
    </div>
    <p>Download YouTube videos in HD quality &mdash; fast &amp; free</p>
  </div>

  <div class="card">
    <div class="url-wrap">
      <span class="url-icon">&#128279;</span>
      <input type="text" id="ytUrl" class="url-input" placeholder="Paste YouTube URL here...">
    </div>

    <div class="quality-row">
      <div class="quality-btn" data-q="144" onclick="selectQuality(this)"><span class="q-icon">&#128241;</span>144p</div>
      <div class="quality-btn" data-q="360" onclick="selectQuality(this)"><span class="q-icon">&#128249;</span>360p</div>
      <div class="quality-btn active" data-q="480" onclick="selectQuality(this)"><span class="q-icon">&#127916;</span>480p</div>
      <div class="quality-btn" data-q="720" onclick="selectQuality(this)"><span class="q-icon">&#128250;</span>720p</div>
      <div class="quality-btn" data-q="1080" onclick="selectQuality(this)"><span class="q-icon">&#127909;</span>1080p</div>
    </div>

    <div class="btn-row">
      <button class="btn-download" id="dlBtn" onclick="startDownload()">
        <span id="dlSpinner" class="spinner"></span>
        <span id="dlLabel">&#11015; Download</span>
      </button>
      <button class="btn-stop" onclick="stopDownload()">&#9209; Stop</button>
    </div>

    <div class="progress-wrap" id="progressWrap">
      <div class="progress-fill" id="progressFill"></div>
    </div>

    <div class="status" id="statusRow">
      <span class="status-text" id="statusText"></span>
      <span class="percent" id="percentText"></span>
    </div>
  </div>

  <div class="footer">Downloads saved to ~/Downloads &nbsp;&middot;&nbsp; Powered by Pakistan Code Center</div>
</div>

<script>
let currentTaskId = null;
let selectedQuality = "480";
let polling = false;

function selectQuality(el) {
  document.querySelectorAll('.quality-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  selectedQuality = el.dataset.q;
}
function setStatus(text, cls = '') {
  document.getElementById('statusRow').className = 'status ' + cls;
  document.getElementById('statusText').textContent = text;
}
function setPercent(p) {
  document.getElementById('percentText').textContent = (p !== null && p !== undefined) ? p + '%' : '';
  document.getElementById('progressFill').style.width = (p || 0) + '%';
  document.getElementById('progressWrap').classList.toggle('visible', p !== null && p !== undefined);
}
function resetBtn() {
  document.getElementById('dlSpinner').classList.remove('active');
  document.getElementById('dlLabel').textContent = '\\u2B07 Download';
  document.getElementById('dlBtn').disabled = false;
  polling = false;
}
async function startDownload() {
  const url = document.getElementById("ytUrl").value.trim();
  if (!url) { setStatus("\\u26A0 Please paste a YouTube URL first.", 'error'); return; }

  const btn = document.getElementById('dlBtn');
  btn.disabled = true;
  document.getElementById('dlSpinner').classList.add('active');
  document.getElementById('dlLabel').textContent = 'Preparing...';
  setStatus('Connecting...', '');
  setPercent(0);

  try {
    const res = await fetch("/download", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url, quality: selectedQuality })
    });
    const d = await res.json();
    if (d.error) { setStatus("\\u274C " + d.error, 'error'); resetBtn(); return; }
    currentTaskId = d.task_id;
    polling = true;
    pollProgress();
  } catch (e) {
    setStatus('\\u274C Failed to start download.', 'error');
    resetBtn();
  }
}
function pollProgress() {
  if (!currentTaskId || !polling) return;
  fetch("/progress/" + currentTaskId)
    .then(r => r.json())
    .then(p => {
      if (p.percent !== undefined) setPercent(p.percent);
      if (p.status === "finished") {
        setStatus('\\u2705 Download complete \\u2014 ' + (p.title || '') + '  (' + (p.size || '') + ')', 'success');
        setPercent(100); resetBtn();
      } else if (p.status === "stopped") {
        setStatus('\\u26D4 Download stopped.', ''); resetBtn();
      } else if (p.error) {
        setStatus("\\u274C " + p.error, 'error'); resetBtn();
      } else if (p.status === "processing") {
        document.getElementById('dlLabel').textContent = 'Processing...';
        setTimeout(pollProgress, 700);
      } else if (p.status === "downloading") {
        document.getElementById('dlLabel').textContent = 'Downloading...';
        setTimeout(pollProgress, 700);
      } else {
        setTimeout(pollProgress, 900);
      }
    })
    .catch(() => setTimeout(pollProgress, 1500));
}
function stopDownload() {
  if (!currentTaskId) return;
  fetch("/stop/" + currentTaskId, { method: "POST" });
  setStatus('Stopping...', '');
}
</script>
</body>
</html>
"""


# -------------------------------
# Backend Logic
# -------------------------------
def build_format_string(quality):
    """Build a format string for yt-dlp.

    If ffmpeg is available we can merge separate video+audio (best quality).
    Otherwise we fall back to pre-muxed progressive streams.
    """
    if quality.isdigit():
        h = quality
        if HAS_FFMPEG:
            return (f"bestvideo[height<={h}]+bestaudio/"
                    f"best[height<={h}]/best")
        return f"best[height<={h}]/best"
    # Unknown quality -> best available
    return "bestvideo+bestaudio/best" if HAS_FFMPEG else "best"


def run_download(task_id, url, quality):
    safe_update_progress(task_id, status="started", percent=0, size="Calculating...")
    stop_flags[task_id] = False

    def hook(d):
        if stop_flags.get(task_id):
            # Tell yt-dlp to abort cleanly.
            raise yt_dlp.utils.DownloadError("Download stopped by user")

        status = d.get("status")
        if status == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate")
            downloaded = d.get("downloaded_bytes", 0)
            percent_val = round((downloaded / total) * 100, 1) if total else 0
            speed = d.get("speed")
            speed_str = f"{speed / 1024 / 1024:.1f} MB/s" if speed else "calculating..."
            size_str = f"{total / (1024 * 1024):.2f} MB" if total else "Unknown size"
            safe_update_progress(
                task_id, status="downloading",
                percent=percent_val, size=size_str, speed=speed_str,
            )
        elif status == "finished":
            # A stream finished; merging/remux may follow.
            if not stop_flags.get(task_id):
                safe_update_progress(task_id, status="processing", percent=100)

    ydl_opts = {
        "format": build_format_string(quality),
        "outtmpl": os.path.join(DOWNLOAD_FOLDER, "%(title)s.%(ext)s"),
        "progress_hooks": [hook],
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "fragment_retries": 10,
        "retries": 10,
        "concurrent_fragment_downloads": 5,  # parallel DASH fragments = faster
        "restrictfilenames": False,
    }
    if HAS_FFMPEG:
        # Guarantee a single, predictable .mp4 output after merge.
        ydl_opts["merge_output_format"] = "mp4"

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            # Single extract+download pass (no wasteful double extraction).
            info = ydl.extract_info(url, download=True)

            if stop_flags.get(task_id):
                safe_update_progress(task_id, status="stopped")
                return

            # Resolve the final file path.
            final_path = ""
            if info:
                downloads = info.get("requested_downloads")
                if downloads:
                    final_path = downloads[0].get("filepath", "")
                if not final_path:
                    final_path = ydl.prepare_filename(info)

            title = info.get("title", "Video") if info else "Video"
            if final_path and os.path.exists(final_path):
                size_mb = os.path.getsize(final_path) / (1024 * 1024)
                safe_update_progress(task_id, status="finished", percent=100,
                                     title=title, size=f"{size_mb:.2f} MB")
            else:
                safe_update_progress(task_id, status="finished", percent=100,
                                     title=title, size="")

    except yt_dlp.utils.DownloadError as e:
        if stop_flags.get(task_id):
            safe_update_progress(task_id, status="stopped")
        else:
            logger.error(f"Task {task_id} download error: {e}")
            safe_update_progress(task_id, error=str(e))
    except Exception as e:
        logger.exception(f"Task {task_id} failed")
        if stop_flags.get(task_id):
            safe_update_progress(task_id, status="stopped")
        else:
            safe_update_progress(task_id, error=str(e))
    finally:
        purge_old_tasks()


# -------------------------------
# Flask Routes
# -------------------------------
@app.route("/")
def index():
    return HTML_PAGE


@app.route("/download", methods=["POST"])
def start_download_route():
    data = request.get_json(silent=True) or {}
    url = (data.get("url") or "").strip()
    quality = str(data.get("quality") or "480")

    if not url:
        return jsonify({"error": "No URL provided"}), 400

    task_id = str(uuid.uuid4())
    threading.Thread(target=run_download, args=(task_id, url, quality), daemon=True).start()
    return jsonify({"task_id": task_id})


@app.route("/progress/<task_id>")
def progress(task_id):
    with state_lock:
        return jsonify(progress_data.get(task_id, {}))


@app.route("/stop/<task_id>", methods=["POST"])
def stop(task_id):
    stop_flags[task_id] = True
    return jsonify({"status": "stopping"})


# -------------------------------
# Main Desktop Window
# -------------------------------
class MainWindow(QMainWindow):
    def __init__(self, port):
        super().__init__()
        self.setWindowTitle("YouTube Downloader HD")
        self.resize(680, 560)
        self.browser = QWebEngineView()
        self.setCentralWidget(self.browser)
        self.browser.setUrl(QUrl(f"http://127.0.0.1:{port}"))


def main():
    port = 5000
    flask_thread = threading.Thread(
        target=lambda: app.run(
            host="127.0.0.1", port=port,
            debug=False, threaded=True, use_reloader=False,
        ),
        daemon=True,
    )
    flask_thread.start()

    qt_app = QApplication(sys.argv)
    win = MainWindow(port)
    win.show()
    sys.exit(qt_app.exec())


if __name__ == "__main__":
    main()