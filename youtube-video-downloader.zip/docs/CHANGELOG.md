# Changelog

All notable changes to this project are documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [Unreleased]

### Planned
- Playlist batch download support
- Audio-only extraction (MP3/AAC)
- Download history panel
- Dark mode UI toggle
- Standalone installer (PyInstaller)

---

## [1.0.0] — 2024-01-01

### 🎉 Initial Release

#### Added
- **Core Download Engine** — powered by `yt-dlp` for reliable, fast YouTube downloads
- **Modern Desktop UI** — built with PySide6 + WebEngine, no Electron required
- **Quality Selection** — choose from 144p, 360p, 480p, 720p, or 1080p
- **Real-time Progress Bar** — live download percentage and speed indicator
- **Stop Download** — cancel any in-progress download instantly
- **FFmpeg Integration** — automatic detection; merges video+audio for HD quality
- **Multi-threaded Backend** — Flask runs on a dedicated thread; UI stays responsive
- **Concurrent Fragment Downloads** — faster downloads via parallel DASH fragment fetching
- **Automatic File Saving** — all downloads saved to `~/Downloads` automatically
- **Task Lifecycle Management** — completed tasks auto-purged after 10 minutes
- **Thread-safe State** — all shared progress data protected with a lock
- **Graceful Stop Handling** — stop flag checked in yt-dlp hook for clean cancellation
- **Flask REST API** — `/download`, `/progress/<id>`, `/stop/<id>` endpoints
- **Beautiful Web UI** — Syne + DM Sans typography, red gradient accent, smooth animations
- **Logging** — structured logging throughout the backend for easy debugging
- **Cross-platform** — tested on Windows, Linux, and macOS

#### Technical Details
- Python 3.11+
- Flask 3.0+
- PySide6 6.6+ with QWebEngineView
- yt-dlp (latest)
- FFmpeg optional (auto-detected via `shutil.which`)
- Default quality: 480p
- Task TTL: 600 seconds (10 minutes)
- Fragment retries: 10
- Connection retries: 10

---

*Maintained by [Pakistan Code Center](https://github.com/your-username)*
