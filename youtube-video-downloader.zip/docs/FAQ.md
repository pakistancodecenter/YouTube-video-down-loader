# Frequently Asked Questions

---

## General

**Q: Is this app free to use?**  
A: Yes. YT Downloader is completely free and open-source under the MIT License.

**Q: Does this app work offline?**  
A: No. An active internet connection is required to download YouTube videos.

**Q: What operating systems are supported?**  
A: Windows, Linux, and macOS are all supported. Windows is the primary development platform.

**Q: Is this legal?**  
A: Downloading YouTube videos may violate YouTube's Terms of Service. This tool is intended for personal, offline use of content you own the rights to, or content that is explicitly licensed for download. Always respect copyright law in your jurisdiction.

---

## Downloads & Quality

**Q: Where are my downloaded files saved?**  
A: All downloads are automatically saved to your home `~/Downloads` folder.  
- Windows: `C:\Users\YourName\Downloads`
- Linux/macOS: `/home/yourname/Downloads`

**Q: Why can't I download in 1080p?**  
A: 1080p (and 720p) requires FFmpeg to merge separate video and audio streams. Install FFmpeg and ensure it's in your system PATH. See [INSTALL.md](INSTALL.md#ffmpeg-setup).

**Q: What format are videos saved in?**  
A: When FFmpeg is available, videos are saved as `.mp4`. Without FFmpeg, the format depends on what YouTube provides (usually `.mp4` or `.webm`).

**Q: Can I download age-restricted or private videos?**  
A: No. Age-restricted and private videos require authentication and are not supported.

**Q: Can I download entire playlists?**  
A: Not in v1.0 — playlist support is planned for v1.1.

---

## Technical

**Q: What is Flask doing inside a desktop app?**  
A: The app embeds a lightweight Flask server locally (on `127.0.0.1:5000`) and uses PySide6's WebEngine to display the UI in a native window. This avoids a heavy frontend build system while keeping a rich browser-rendered interface.

**Q: Why does the terminal stay open?**  
A: The terminal shows real-time logs from Flask and yt-dlp. You can safely ignore it during normal use.

**Q: Does the app send any data externally?**  
A: No. All traffic goes directly between your machine and YouTube's servers via yt-dlp. No analytics or telemetry are collected.

**Q: My antivirus flagged this app — is it safe?**  
A: Some antivirus software flags Python apps that bundle web servers as suspicious. The source code is fully open — review `YouTubeVedioDownloader.py` yourself. You can also run it from source rather than a packaged executable.

---

## Errors

**Q: I get a blank white window on startup.**  
A: The Flask server may not have started before the browser loaded. Wait 2–3 seconds and refresh, or restart the app.

**Q: Download fails with "yt-dlp error".**  
A: YouTube frequently changes its internal API. Update yt-dlp with:
```bash
pip install --upgrade yt-dlp
```

**Q: I get `Address already in use` error.**  
A: Port 5000 is in use by another process. Kill it or change the port in the source code (`port = 5000` in the `main()` function).

**Q: The progress bar doesn't move.**  
A: This can happen on very short videos (< 1 MB) where the download completes before the first poll. Check your `~/Downloads` folder — the file may already be there.
