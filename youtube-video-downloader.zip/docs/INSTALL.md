# Installation Guide

This document provides detailed installation instructions for all supported platforms.

---

## Table of Contents

- [System Requirements](#system-requirements)
- [Windows Installation](#windows-installation)
- [Linux Installation](#linux-installation)
- [macOS Installation](#macos-installation)
- [FFmpeg Setup](#ffmpeg-setup)
- [Verifying the Installation](#verifying-the-installation)
- [Troubleshooting](#troubleshooting)

---

## System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| Python | 3.11 | 3.12 |
| RAM | 256 MB | 512 MB |
| Disk Space | 50 MB | 200 MB |
| Internet | Required | Stable broadband |
| FFmpeg | Optional | Recommended |

---

## Windows Installation

### Step 1 — Install Python

1. Visit [https://www.python.org/downloads/](https://www.python.org/downloads/)
2. Download **Python 3.11** or higher
3. Run the installer — **check "Add Python to PATH"** before clicking Install
4. Verify: open a terminal and run:
   ```
   python --version
   ```

### Step 2 — Clone the Repository

```bash
git clone https://github.com/your-username/youtube-video-downloader.git
cd youtube-video-downloader
```

Or download the ZIP from the GitHub releases page.

### Step 3 — Create a Virtual Environment *(Recommended)*

```bash
python -m venv venv
venv\Scripts\activate
```

### Step 4 — Install Dependencies

```bash
pip install -r requirements.txt
```

### Step 5 — Run the App

```bash
python YouTubeVedioDownloader.py
```

---

## Linux Installation

### Ubuntu / Debian

```bash
# Update package list
sudo apt update

# Install Python and pip
sudo apt install python3.11 python3-pip python3-venv -y

# Install system libraries required by PySide6
sudo apt install libglib2.0-0 libgl1-mesa-glx -y

# Clone the repo
git clone https://github.com/your-username/youtube-video-downloader.git
cd youtube-video-downloader

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run
python3 YouTubeVedioDownloader.py
```

### Fedora / RHEL

```bash
sudo dnf install python3.11 python3-pip -y
# Then follow the same steps as Ubuntu above
```

---

## macOS Installation

```bash
# Install Homebrew (if not already installed)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Python
brew install python@3.11

# Clone the repo
git clone https://github.com/your-username/youtube-video-downloader.git
cd youtube-video-downloader

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run
python3 YouTubeVedioDownloader.py
```

---

## FFmpeg Setup

### Why FFmpeg?

FFmpeg enables the app to merge separate video and audio streams — required for true 720p and 1080p quality downloads. Without it, the app falls back to pre-muxed progressive streams.

### Windows

1. Download from [https://www.gyan.dev/ffmpeg/builds/](https://www.gyan.dev/ffmpeg/builds/) — choose `ffmpeg-release-full.7z`
2. Extract to `C:\ffmpeg`
3. Add `C:\ffmpeg\bin` to your **System PATH**
4. Verify: `ffmpeg -version`

### Linux

```bash
sudo apt install ffmpeg -y
ffmpeg -version
```

### macOS

```bash
brew install ffmpeg
ffmpeg -version
```

---

## Verifying the Installation

After running the app, you should see:

1. A native desktop window titled **"YouTube Downloader HD"**
2. No error messages in the terminal (only info logs)
3. A log line confirming FFmpeg status:
   - `✅ ffmpeg found` — HD merging available
   - `⚠️ ffmpeg not found` — fallback mode active

---

## Troubleshooting

### `ModuleNotFoundError: No module named 'PySide6'`
Run `pip install PySide6 PySide6-WebEngine` and ensure your virtual environment is activated.

### `ModuleNotFoundError: No module named 'yt_dlp'`
Run `pip install yt-dlp`.

### Window appears blank / white screen
Wait 2–3 seconds for the Flask server to start. On slower machines, the embedded browser may load before Flask is ready.

### Download fails immediately
Ensure the YouTube URL is valid and publicly accessible. Age-restricted or private videos are not supported.

### FFmpeg not detected despite being installed
Ensure FFmpeg's `bin` folder is in your system `PATH` and open a fresh terminal after updating PATH.
